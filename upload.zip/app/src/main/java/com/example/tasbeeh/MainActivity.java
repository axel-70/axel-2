package com.example.tasbeeh;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String BG = "#0B1F1A";
    private static final String CARD = "#12332B";
    private static final String GOLD = "#E8C872";
    private static final String MUTED = "#9DB8AE";

    private final String[] dhikr = {
        "سبحان الله",
        "الحمد لله",
        "الله أكبر",
        "لا إله إلا الله",
        "أستغفر الله",
        "سبحان الله وبحمده",
        "اللهم صلِّ على محمد"
    };
    private final int[] targets = {33, 100, 500, 1000, 0};
    private final int[] counts = new int[dhikr.length];
    private int idx = 0, tIdx = 0;
    private boolean confirmReset = false;

    private SharedPreferences sp;
    private Vibrator vib;
    private TextView dhikrView, targetView, statsView;
    private Ring ring;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor(BG));
        getWindow().setNavigationBarColor(Color.parseColor(BG));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        sp = getSharedPreferences("tasbeeh", MODE_PRIVATE);
        vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        idx = Math.min(Math.max(sp.getInt("idx", 0), 0), dhikr.length - 1);
        tIdx = Math.min(Math.max(sp.getInt("t", 0), 0), targets.length - 1);
        for (int i = 0; i < counts.length; i++) counts[i] = sp.getInt("c" + i, 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor(BG));
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("المسبحة");
        title.setTextColor(Color.parseColor(MUTED));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        // dhikr selector row
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView nextBtn = arrow("‹");
        TextView prevBtn = arrow("›");
        dhikrView = new TextView(this);
        dhikrView.setTextColor(Color.parseColor(GOLD));
        dhikrView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        dhikrView.setTypeface(Typeface.DEFAULT_BOLD);
        dhikrView.setGravity(Gravity.CENTER);
        dhikrView.setMaxLines(2);
        head.addView(nextBtn, new LinearLayout.LayoutParams(dp(56), dp(56)));
        head.addView(dhikrView, new LinearLayout.LayoutParams(0, dp(84), 1f));
        head.addView(prevBtn, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-1, -2);
        hlp.topMargin = dp(8);
        root.addView(head, hlp);

        nextBtn.setOnClickListener(v -> {
            idx = (idx + 1) % dhikr.length;
            save();
            refresh();
        });
        prevBtn.setOnClickListener(v -> {
            idx = (idx - 1 + dhikr.length) % dhikr.length;
            save();
            refresh();
        });

        // target chip
        targetView = pill("", 16, CARD, GOLD);
        targetView.setOnClickListener(v -> {
            tIdx = (tIdx + 1) % targets.length;
            save();
            refresh();
        });
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.gravity = Gravity.CENTER_HORIZONTAL;
        tlp.topMargin = dp(4);
        root.addView(targetView, tlp);

        // ring
        ring = new Ring();
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, 0, 1f);
        rlp.topMargin = dp(12);
        rlp.bottomMargin = dp(12);
        root.addView(ring, rlp);
        ring.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            counts[idx]++;
            int t = targets[tIdx];
            if (t > 0 && counts[idx] % t == 0) buzz(350);
            save();
            refresh();
        });

        statsView = new TextView(this);
        statsView.setTextColor(Color.parseColor(MUTED));
        statsView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        statsView.setGravity(Gravity.CENTER);
        root.addView(statsView, new LinearLayout.LayoutParams(-1, -2));

        // bottom buttons
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        final TextView undoBtn = pill("تراجع", 18, CARD, "#FFFFFF");
        final TextView resetBtn = pill("تصفير", 18, "#5A2A2A", "#FFFFFF");
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, -2, 1f);
        blp.setMargins(dp(6), dp(12), dp(6), 0);
        bottom.addView(undoBtn, blp);
        bottom.addView(resetBtn, blp);
        root.addView(bottom, new LinearLayout.LayoutParams(-1, -2));

        undoBtn.setOnClickListener(v -> {
            if (counts[idx] > 0) counts[idx]--;
            save();
            refresh();
        });
        resetBtn.setOnClickListener(v -> {
            if (!confirmReset) {
                confirmReset = true;
                resetBtn.setText("اضغط للتأكيد");
                resetBtn.postDelayed(() -> {
                    confirmReset = false;
                    resetBtn.setText("تصفير");
                }, 2500);
            } else {
                confirmReset = false;
                resetBtn.setText("تصفير");
                counts[idx] = 0;
                save();
                refresh();
            }
        });

        setContentView(root);
        refresh();
    }

    private void save() {
        SharedPreferences.Editor e = sp.edit();
        e.putInt("idx", idx);
        e.putInt("t", tIdx);
        for (int i = 0; i < counts.length; i++) e.putInt("c" + i, counts[i]);
        e.apply();
    }

    private void refresh() {
        int t = targets[tIdx];
        dhikrView.setText(dhikr[idx]);
        targetView.setText(t == 0 ? "الهدف: مفتوح" : "الهدف: " + t);
        ring.set(counts[idx], t);
        int total = 0;
        for (int c : counts) total += c;
        int rounds = t > 0 ? counts[idx] / t : 0;
        statsView.setText("الدورات: " + rounds + "   •   إجمالي كل الأذكار: " + total);
    }

    private void buzz(long ms) {
        if (vib != null && vib.hasVibrator()) {
            vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }

    private TextView arrow(String s) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(Color.parseColor(MUTED));
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 40);
        v.setGravity(Gravity.CENTER);
        v.setClickable(true);
        return v;
    }

    private TextView pill(String text, int size, String bg, String fg) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.parseColor(fg));
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(20), dp(12), dp(20), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(bg));
        g.setCornerRadius(dp(28));
        v.setBackground(new RippleDrawable(
                ColorStateList.valueOf(Color.argb(80, 255, 255, 255)), g, null));
        v.setClickable(true);
        return v;
    }

    private class Ring extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint prog = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sub = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int count = 0, target = 33;

        Ring() {
            super(MainActivity.this);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Color.parseColor(CARD));
            track.setStyle(Paint.Style.STROKE);
            track.setStrokeWidth(dp(12));
            track.setColor(Color.parseColor("#1F4A3E"));
            prog.setStyle(Paint.Style.STROKE);
            prog.setStrokeWidth(dp(12));
            prog.setStrokeCap(Paint.Cap.ROUND);
            prog.setColor(Color.parseColor(GOLD));
            txt.setColor(Color.WHITE);
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            sub.setColor(Color.parseColor(MUTED));
            sub.setTextAlign(Paint.Align.CENTER);
            sub.setTextSize(sp(15));
            setClickable(true);
        }

        void set(int c, int t) {
            count = c;
            target = t;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float rad = Math.min(getWidth(), getHeight()) / 2f - dp(12);
            canvas.drawCircle(cx, cy, rad, fill);
            canvas.drawCircle(cx, cy, rad, track);
            float sweep = 0f;
            if (target > 0 && count > 0) {
                int m = count % target;
                sweep = (m == 0) ? 360f : 360f * m / target;
            }
            if (sweep > 0f) {
                canvas.drawArc(new RectF(cx - rad, cy - rad, cx + rad, cy + rad),
                        -90f, sweep, false, prog);
            }
            txt.setTextSize(sp(count >= 10000 ? 48 : count >= 1000 ? 60 : 76));
            float y = cy - (txt.descent() + txt.ascent()) / 2f;
            canvas.drawText(String.valueOf(count), cx, y, txt);
            canvas.drawText("اضغط للتسبيح", cx, cy + rad * 0.55f, sub);
        }
    }
}
